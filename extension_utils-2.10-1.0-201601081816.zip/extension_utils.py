#!/usr/bin/python

from py4j.protocol import Py4JJavaError, Py4JError
from pyspark.sql import DataFrame, SQLContext

class ExtensionUtils(object):
    def __init__(self, sc):
        try:
            self.sc = sc
            self.scala_obj = self.sc._jvm.com.ibm.spark.ingest.ExtensionUtils
        except Py4JError:
            print "Error: PySpark cannot find ibmprofile.jar"

    def printProfile(self, df):
        try:
	    if isinstance(df, DataFrame):
        	return self.scala_obj.printProfile(df._jdf)
	    else: 
		return self.scala_obj.printProfile(df)
		
        except Py4JJavaError:
	    print "Error: PrintProfile"

    def profile(self, df):
        try:
	    if isinstance(df, DataFrame):
	        return self.scala_obj.profile(df._jdf)
	    else: 
		return self.scala_obj.profile(df)

        except Py4JJavaError:
            return self.scala_obj.profile(df)
	
    def inferTypes(self, df, dictVal={}):
        try:
	    if dictVal is None:
	    	return self.scala_obj.inferTypes(df._jdf)
	    else:
            	return self.scala_obj.inferTypes(df._jdf, dictVal)
        except Py4JJavaError:
            return self.scala_obj.inferTypes(df)

    def printTypes(self, df):
        try:
	    if isinstance(df, DataFrame):
        	return self.scala_obj.printTypes(df._jdf)
	    else: 
		return self.scala_obj.printTypes(df)
		
        except Py4JJavaError:
	    print "Error: PrintTypes"

    def showProfile(self, df):
        try:
	    if isinstance(df, DataFrame):
        	return self.scala_obj.showProfile(df._jdf)
	    else: 
		return self.scala_obj.showProfile(df)
		
        except Py4JJavaError:
	    print "Error: showProfile"
