#!/usr/bin/python

from py4j.protocol import Py4JJavaError, Py4JError
from pyspark.sql import DataFrame, SQLContext

__all__ = ["DataFrame"]

class ExtensionUtils(object):
    def __init__(self, sql_ctx):
        try:
            self.sql_ctx = sql_ctx
            self.sc = sql_ctx and sql_ctx._sc
            self.scala_obj = self.sc._jvm.com.ibm.spark.ingest.ExtensionUtils
        except Py4JError:
            print "Error: PySpark cannot find ibmprofile.jar"

    def printProfile(self, df):
        try:
	    if isinstance(df, DataFrame):
                # To print on pyspark we need to refactor printProfile scala code to 
                # return as string and then call print(self.scala_obj.printProfile(df._jdf))
        	self.scala_obj.printProfile(df._jdf)
	    else: 
		self.scala_obj.printProfile(df)
		
        except Py4JJavaError:
	    print "Error: PrintProfile"

    def profile(self, df):
        try:
	    if isinstance(df, DataFrame):
	        return DataFrame(self.scala_obj.profile(df._jdf), self.sql_ctx)
	    else: 
		return DataFrame(self.scala_obj.profile(df), self.sql_ctx)

        except Py4JJavaError:
            return DataFrame(self.scala_obj.profile(df), self.sql_ctx)
	
    def inferTypes(self, df, dictVal={}):
        try:
	    if dictVal is None:
	    	return DataFrame(self.scala_obj.inferTypes(df._jdf), self.sql_ctx)
	    else:
            	return DataFrame(self.scala_obj.inferTypes(df._jdf, dictVal), self.sql_ctx)
        except Py4JJavaError:
            return DataFrame(self.scala_obj.inferTypes(df), self.sql_ctx)

    def printTypes(self, df):
        try:
	    if isinstance(df, DataFrame):
        	return self.scala_obj.printTypes(df._jdf)
	    else: 
		return self.scala_obj.printTypes(df)
		
        except Py4JJavaError:
	    print "Error: PrintTypes"

    def showProfile(self, df):
        try:
	    if isinstance(df, DataFrame):
        	return self.scala_obj.showProfile(df._jdf)
	    else: 
		return self.scala_obj.showProfile(df)
		
        except Py4JJavaError:
	    print "Error: showProfile"
